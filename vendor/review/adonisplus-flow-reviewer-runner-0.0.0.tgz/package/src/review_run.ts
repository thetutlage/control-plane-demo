/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { join } from 'node:path'
import { readFile, rm } from 'node:fs/promises'
import { query, type Options, type SDKResultMessage } from '@anthropic-ai/claude-agent-sdk'

/** Where the code-review skill writes its findings, relative to the repo. */
export const FINDINGS_FILE = 'tmp/code-review.json'

export type QueryFn = typeof query

export interface ReviewRunOptions {
  cwd: string
  base: string
  head: string
  maxBudgetUsd: number
}

/** The cost and tokens of one model in a run. */
export interface ModelCost {
  model: string
  costUsd: number
  inputTokens: number
  outputTokens: number
  cacheReadInputTokens: number
  cacheCreationInputTokens: number
}

export interface ReviewCost {
  totalCostUsd: number
  durationMs: number
  numTurns: number
  models: ModelCost[]
}

export interface ReviewRunResult {
  findings: unknown
  cost: ReviewCost
}

/**
 * A run that ended without findings. It keeps the cost, since the customer
 * pays for a failed run too.
 */
export class ReviewRunError extends Error {
  constructor(
    message: string,
    public cost: ReviewCost | null
  ) {
    super(message)
  }
}

/**
 * Runs the code-review skill of Flow on a diff with the Claude Agent SDK, then
 * reads the findings file that the skill writes.
 */
export class ReviewRun {
  constructor(private queryFn: QueryFn = query) {}

  /**
   * The SDK options of a run. The project setting source loads the skills,
   * the agent files and CLAUDE.md that `npx flow install` wrote. Bash is
   * limited to the commands of the skill.
   */
  options(run: ReviewRunOptions): Options {
    return {
      cwd: run.cwd,
      model: 'opus',
      settingSources: ['project'],
      skills: 'all',
      tools: ['Read', 'Glob', 'Grep', 'Write', 'Agent', 'Skill', 'Bash'],
      allowedTools: [
        'Read',
        'Glob',
        'Grep',
        'Write',
        'Agent',
        'Bash(npx flow review-plan:*)',
        'Bash(git diff:*)',
        'Bash(git show:*)',
      ],
      permissionMode: 'dontAsk',
      maxBudgetUsd: run.maxBudgetUsd,
      env: { ...process.env, CLAUDE_CODE_DISABLE_BACKGROUND_TASKS: '1' },
    }
  }

  async run(run: ReviewRunOptions): Promise<ReviewRunResult> {
    const findingsPath = join(run.cwd, FINDINGS_FILE)
    await rm(findingsPath, { force: true })

    let result: SDKResultMessage | undefined
    const messages = this.queryFn({
      prompt: `/flow-code-review Review the diff between ${run.base} and ${run.head}. Do not print the findings.`,
      options: this.options(run),
    })
    for await (const message of messages) {
      if (message.type === 'result') result = message
    }

    if (!result) {
      throw new ReviewRunError('The review ended without a result', null)
    }

    const cost = this.#cost(result)
    if (result.subtype !== 'success') {
      const errors = result.errors.length ? `: ${result.errors.join('; ')}` : ''
      throw new ReviewRunError(`The review failed with ${result.subtype}${errors}`, cost)
    }

    const raw = await readFile(findingsPath, 'utf8').catch(() => null)
    if (raw === null) {
      throw new ReviewRunError(`The review did not write ${FINDINGS_FILE}`, cost)
    }

    try {
      return { findings: JSON.parse(raw), cost }
    } catch {
      throw new ReviewRunError(`${FINDINGS_FILE} is not valid JSON`, cost)
    }
  }

  #cost(result: SDKResultMessage): ReviewCost {
    return {
      totalCostUsd: result.total_cost_usd,
      durationMs: result.duration_ms,
      numTurns: result.num_turns,
      models: Object.entries(result.modelUsage).map(([model, usage]) => ({
        model,
        costUsd: usage.costUSD,
        inputTokens: usage.inputTokens,
        outputTokens: usage.outputTokens,
        cacheReadInputTokens: usage.cacheReadInputTokens,
        cacheCreationInputTokens: usage.cacheCreationInputTokens,
      })),
    }
  }
}
