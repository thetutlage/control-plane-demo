/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

export const SEVERITIES = ['critical', 'major', 'minor', 'nit'] as const
export type Severity = (typeof SEVERITIES)[number]

/** One finding of the code-review skill, as it writes them to its findings file. */
export interface Finding {
  lens: string[]
  severity: Severity
  consequence?: string
  likelihood?: string
  path: string
  line: number
  endLine?: number
  problem: string
  impact: string
  fix: string
  suggestion?: string
}

/** The decision of the code-re-review skill on an earlier Flow comment. */
export interface ThreadDecision {
  id: string
  fixed: boolean
  reason: string
}

/** The findings file of the code-review and the code-re-review skills. */
export interface FindingsFile {
  findings: Finding[]
  messages: string[]
  threads: ThreadDecision[]
}

/**
 * Reads the findings file that the skill wrote. Throws when a finding misses
 * a field that posting needs.
 */
export function parseFindings(json: unknown): FindingsFile {
  const file = json as { findings?: unknown; messages?: unknown; threads?: unknown }
  if (!Array.isArray(file?.findings)) {
    throw new Error('The findings file has no "findings" list')
  }

  const findings = file.findings.map((item, index) => {
    const finding = item as Partial<Finding>
    for (const key of ['path', 'problem', 'impact', 'fix'] as const) {
      if (typeof finding[key] !== 'string') {
        throw new Error(`findings[${index}] needs a "${key}"`)
      }
    }
    if (!Number.isInteger(finding.line)) throw new Error(`findings[${index}] needs a "line"`)
    if (!SEVERITIES.includes(finding.severity as Severity)) {
      throw new Error(`findings[${index}] has an unknown severity "${finding.severity}"`)
    }
    return { ...finding, lens: Array.isArray(finding.lens) ? finding.lens : [] } as Finding
  })

  const messages = Array.isArray(file.messages)
    ? file.messages.filter((message): message is string => typeof message === 'string')
    : []
  const threads = (Array.isArray(file.threads) ? file.threads : [])
    .map((item) => item as Partial<ThreadDecision>)
    .filter((item) => typeof item?.id === 'string' && typeof item.fixed === 'boolean')
    .map((item) => ({ id: item.id!, fixed: item.fixed!, reason: String(item.reason ?? '') }))
  return { findings, messages, threads }
}
