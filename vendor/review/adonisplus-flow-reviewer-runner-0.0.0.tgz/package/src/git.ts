/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { promisify } from 'node:util'
import { execFile } from 'node:child_process'

const run = promisify(execFile)

/** Runs a command in the repo and returns its trimmed output. */
async function exec(cwd: string, command: string, args: string[]): Promise<string> {
  try {
    const { stdout } = await run(command, args, { cwd, maxBuffer: 10 * 1024 * 1024 })
    return stdout.trim()
  } catch (error) {
    const stderr = (error as { stderr?: string }).stderr?.trim()
    throw new Error(`${command} ${args.join(' ')} failed${stderr ? `: ${stderr}` : ''}`)
  }
}

/** The commit that a branch, a tag or a commit names. */
export function resolveCommit(cwd: string, ref: string): Promise<string> {
  return exec(cwd, 'git', ['rev-parse', `${ref}^{commit}`])
}

/** The number of lenses that `npx flow review-plan` plans for the diff. */
export async function plannedLenses(cwd: string, base: string, head: string): Promise<number> {
  const plan = JSON.parse(await exec(cwd, 'npx', ['flow', 'review-plan', base, head]))
  return Array.isArray(plan.lenses) ? plan.lenses.length : 0
}
