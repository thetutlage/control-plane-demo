/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { promisify } from 'node:util'
import { execFile } from 'node:child_process'

const run = promisify(execFile)

/** Runs a command in the repo and returns its trimmed output. */
async function exec(cwd: string, command: string, args: string[]): Promise<string> {
  try {
    const { stdout } = await run(command, args, { cwd, maxBuffer: 10 * 1024 * 1024 })
    return stdout.trim()
  } catch (error) {
    const stderr = (error as { stderr?: string }).stderr?.trim()
    throw new Error(`${command} ${args.join(' ')} failed${stderr ? `: ${stderr}` : ''}`)
  }
}

/** The commit that a branch, a tag or a commit names. */
export function resolveCommit(cwd: string, ref: string): Promise<string> {
  return exec(cwd, 'git', ['rev-parse', `${ref}^{commit}`])
}

/** The merge base of two commits: where the head left the base. */
export function mergeBase(cwd: string, base: string, head: string): Promise<string> {
  return exec(cwd, 'git', ['merge-base', base, head])
}

/**
 * Makes sure the repo has a commit. After a force push, the commit of an
 * earlier review is not on a branch, so it is fetched by its sha. Returns
 * `false` when GitHub no longer has it.
 */
export async function fetchCommit(cwd: string, sha: string): Promise<boolean> {
  try {
    await exec(cwd, 'git', ['cat-file', '-e', `${sha}^{commit}`])
    return true
  } catch {
    return exec(cwd, 'git', ['fetch', '--no-tags', '--quiet', 'origin', sha]).then(
      () => true,
      () => false
    )
  }
}

/** A lens that `npx flow review-plan` plans for a diff, with the path of its file. */
export interface PlannedLens {
  lens: string
  ref: string
}

/**
 * The lenses that `npx flow review-plan` plans for the diff. With `since`,
 * only the lenses with files that changed after that commit.
 */
export async function plannedLenses(
  cwd: string,
  base: string,
  head: string,
  since?: string
): Promise<PlannedLens[]> {
  const args = ['flow', 'review-plan', base, head, ...(since ? [`--since=${since}`] : [])]
  const plan = JSON.parse(await exec(cwd, 'npx', args))
  return Array.isArray(plan.lenses)
    ? plan.lenses.map((lens: PlannedLens) => ({ lens: lens.lens, ref: lens.ref }))
    : []
}
