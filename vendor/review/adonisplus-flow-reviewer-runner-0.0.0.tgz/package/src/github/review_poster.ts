/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import type { FindingsFile, Finding } from '../findings.ts'
import { commentableLines } from './commentable_lines.ts'
import { commentBody, reviewBody, severityCounts } from './format.ts'

export interface ReviewComment {
  path: string
  line: number
  startLine?: number
  body: string
}

/** The calls to GitHub that posting needs. */
export interface GitHubClient {
  listFiles(pr: number): Promise<{ filename: string; patch?: string }[]>
  createReview(
    pr: number,
    review: { commitId: string; body: string; comments: ReviewComment[] }
  ): Promise<void>
  createCheckRun(check: {
    headSha: string
    conclusion: 'success' | 'failure'
    title: string
    summary: string
  }): Promise<void>
}

export interface PostOptions {
  pr: number
  base: string
  head: string
  lensesRan: number
  file: FindingsFile
}

export interface PostResult {
  inline: number
  outside: number
  conclusion: 'success' | 'failure'
}

/**
 * Posts the findings of a review as one pull request review, with an inline
 * comment for each finding on a line of the diff, and a check run that fails
 * on a critical or a major finding.
 */
export class ReviewPoster {
  constructor(private client: GitHubClient) {}

  async post(options: PostOptions): Promise<PostResult> {
    const files = await this.client.listFiles(options.pr)
    const lines = new Map(files.map((file) => [file.filename, commentableLines(file.patch)]))

    const inline: Finding[] = []
    const outside: Finding[] = []
    for (const finding of options.file.findings) {
      ;(this.#inDiff(finding, lines) ? inline : outside).push(finding)
    }

    const review = (inDiff: Finding[], notInDiff: Finding[]) => ({
      commitId: options.head,
      body: reviewBody({
        findings: options.file.findings,
        outside: notInDiff,
        messages: options.file.messages,
        lensesRan: options.lensesRan,
        base: options.base,
        head: options.head,
      }),
      comments: inDiff.map((finding) => this.#comment(finding)),
    })

    /**
     * GitHub rejects the whole review when it cannot place one comment, and
     * does not say which one. The review then posts again with every finding
     * in its body.
     */
    let posted = { inline: inline.length, outside: outside.length }
    try {
      await this.client.createReview(options.pr, review(inline, outside))
    } catch (error) {
      if ((error as { status?: number }).status !== 422) throw error
      await this.client.createReview(options.pr, review([], options.file.findings))
      posted = { inline: 0, outside: options.file.findings.length }
    }

    const blocking = options.file.findings.filter(
      (finding) => finding.severity === 'critical' || finding.severity === 'major'
    )
    const conclusion = blocking.length ? 'failure' : 'success'
    await this.client.createCheckRun({
      headSha: options.head,
      conclusion,
      title: severityCounts(options.file.findings),
      summary: blocking.length
        ? `${blocking.length} critical or major finding(s) to fix before merging.`
        : 'No critical or major finding.',
    })

    return { ...posted, conclusion }
  }

  /** Whether each line of the finding is a line GitHub accepts a comment on. */
  #inDiff(finding: Finding, lines: Map<string, Set<number>>): boolean {
    const accepted = lines.get(finding.path)
    if (!accepted) return false
    const end = finding.endLine ?? finding.line
    for (let line = finding.line; line <= end; line++) {
      if (!accepted.has(line)) return false
    }
    return true
  }

  #comment(finding: Finding): ReviewComment {
    const end = finding.endLine ?? finding.line
    return {
      path: finding.path,
      line: end,
      ...(end > finding.line ? { startLine: finding.line } : {}),
      body: commentBody(finding),
    }
  }
}
