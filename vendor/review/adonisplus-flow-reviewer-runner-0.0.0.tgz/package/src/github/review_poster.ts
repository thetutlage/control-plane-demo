/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import type { FindingsFile, Finding } from '../findings.ts'
import type { ThreadEntry } from './earlier_review.ts'
import { commentableLines } from './commentable_lines.ts'
import { commentBody, reviewBody, severityCounts, type OutsideItem } from './format.ts'

export interface ReviewComment {
  path: string
  line: number
  startLine?: number
  body: string
}

/** The calls to GitHub that posting needs. */
export interface GitHubClient {
  listFiles(pr: number): Promise<{ filename: string; patch?: string }[]>
  createReview(
    pr: number,
    review: { commitId: string; body: string; comments: ReviewComment[] }
  ): Promise<void>
  replyToThread(threadId: string, body: string): Promise<void>
  resolveThread(threadId: string): Promise<void>
  createCheckRun(check: {
    headSha: string
    conclusion: 'success' | 'failure'
    title: string
    summary: string
  }): Promise<void>
}

export interface PostOptions {
  pr: number
  base: string
  head: string
  lensesRan: number

  /** The lens files of each lens, by its name, for the markers of the comments. */
  refs: Map<string, string>
  file: FindingsFile

  /** On a re-review: the commit of the earlier review and the earlier Flow comments. */
  earlier?: { since: string; threads: ThreadEntry[] }
}

export interface PostResult {
  inline: number
  outside: number
  resolved: number

  /** The earlier comments that the re-review gave no decision on. They stay open. */
  undecided: string[]
  conclusion: 'success' | 'failure'
}

const BLOCKING = new Set(['critical', 'major'])

/**
 * Posts the findings of a review as one pull request review, with an inline
 * comment for each finding on a line of the diff, and a check run that fails
 * while a critical or a major Flow finding is open. On a re-review, it first
 * replies to and resolves each earlier Flow comment that the new commits fix.
 */
export class ReviewPoster {
  constructor(private client: GitHubClient) {}

  async post(options: PostOptions): Promise<PostResult> {
    const earlier = this.#settleEarlier(options)
    for (const thread of earlier.fixed) {
      await this.client.replyToThread(
        thread.entry.id,
        `Addressed in ${options.head.slice(0, 7)}. ${thread.reason}`.trim()
      )
      await this.client.resolveThread(thread.entry.id)
    }

    const files = await this.client.listFiles(options.pr)
    const lines = new Map(files.map((file) => [file.filename, commentableLines(file.patch)]))

    const inline: Finding[] = []
    const outside: Finding[] = []
    for (const finding of options.file.findings) {
      ;(this.#inDiff(finding, lines) ? inline : outside).push(finding)
    }

    const review = (inDiff: Finding[], notInDiff: Finding[]) => ({
      commitId: options.head,
      body: reviewBody({
        findings: options.file.findings,
        outside: notInDiff,
        openOutside: [
          ...earlier.openOutside,
          ...notInDiff.map((finding, index) => this.#outsideItem(finding, index, options)),
        ],
        messages: options.file.messages,
        lensesRan: options.lensesRan,
        base: options.base,
        head: options.head,
        ...(options.earlier
          ? { reReview: { since: options.earlier.since, resolved: earlier.resolved } }
          : {}),
      }),
      comments: inDiff.map((finding) => this.#comment(finding, options)),
    })

    /**
     * GitHub rejects the whole review when it cannot place one comment, and
     * does not say which one. The review then posts again with every finding
     * in its body.
     */
    let posted = { inline: inline.length, outside: outside.length }
    try {
      await this.client.createReview(options.pr, review(inline, outside))
    } catch (error) {
      if ((error as { status?: number }).status !== 422) throw error
      await this.client.createReview(options.pr, review([], options.file.findings))
      posted = { inline: 0, outside: options.file.findings.length }
    }

    const open = [...earlier.open, ...options.file.findings]
    const blocking = open.filter((item) => BLOCKING.has(item.severity))
    const conclusion = blocking.length ? 'failure' : 'success'
    await this.client.createCheckRun({
      headSha: options.head,
      conclusion,
      title: open.length ? `${severityCounts(open)} open` : 'no open findings',
      summary: blocking.length
        ? `${blocking.length} critical or major Flow finding(s) open. Fix them before merging.`
        : 'No critical or major Flow finding is open.',
    })

    return {
      ...posted,
      resolved: earlier.resolved,
      undecided: earlier.undecided,
      conclusion,
    }
  }

  /**
   * Sorts the earlier Flow comments by the decisions of the re-review. An
   * open comment or a finding outside the diff with no decision stays open.
   */
  #settleEarlier(options: PostOptions) {
    const decisions = new Map(options.file.threads.map((decision) => [decision.id, decision]))
    const fixed: { entry: ThreadEntry; reason: string }[] = []
    const open: ThreadEntry[] = []
    const openOutside: OutsideItem[] = []
    const undecided: string[] = []
    let fixedOutside = 0

    for (const entry of options.earlier?.threads ?? []) {
      if (entry.state === 'resolved') continue
      const decision = decisions.get(entry.id)
      if (!decision) undecided.push(entry.id)

      if (decision?.fixed) {
        if (entry.state === 'open') fixed.push({ entry, reason: decision.reason })
        else fixedOutside++
      } else {
        open.push(entry)
        if (entry.state === 'outside') openOutside.push(this.#carriedOutside(entry))
      }
    }
    return { fixed, open, openOutside, undecided, resolved: fixed.length + fixedOutside }
  }

  /** A finding outside the diff of an earlier review, kept for the next marker. */
  #carriedOutside(entry: ThreadEntry): OutsideItem {
    const [problem, fix = ''] = entry.body.split(' **Fix:** ')
    return {
      id: entry.id,
      path: entry.path,
      line: entry.line ?? 0,
      lens: [],
      refs: entry.refs,
      severity: entry.severity,
      problem,
      fix,
    }
  }

  #outsideItem(finding: Finding, index: number, options: PostOptions): OutsideItem {
    return {
      id: `outside-${options.head.slice(0, 7)}-${index + 1}`,
      path: finding.path,
      line: finding.line,
      lens: finding.lens,
      refs: this.#refs(finding, options),
      severity: finding.severity,
      problem: finding.problem,
      fix: finding.fix,
    }
  }

  #refs(finding: Finding, options: PostOptions): string[] {
    return finding.lens.flatMap((lens) => options.refs.get(lens) ?? [])
  }

  /** Whether each line of the finding is a line GitHub accepts a comment on. */
  #inDiff(finding: Finding, lines: Map<string, Set<number>>): boolean {
    const accepted = lines.get(finding.path)
    if (!accepted) return false
    const end = finding.endLine ?? finding.line
    for (let line = finding.line; line <= end; line++) {
      if (!accepted.has(line)) return false
    }
    return true
  }

  #comment(finding: Finding, options: PostOptions): ReviewComment {
    const end = finding.endLine ?? finding.line
    return {
      path: finding.path,
      line: end,
      ...(end > finding.line ? { startLine: finding.line } : {}),
      body: commentBody(finding, this.#refs(finding, options)),
    }
  }
}
