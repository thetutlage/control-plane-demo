/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * The lines of the new file that GitHub accepts a review comment on: the
 * added lines and the context lines of each hunk of a file's patch.
 */
export function commentableLines(patch: string | undefined): Set<number> {
  const lines = new Set<number>()
  if (!patch) return lines

  let newLine = 0
  for (const line of patch.split('\n')) {
    const hunk = line.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/)
    if (hunk) {
      newLine = Number(hunk[1])
      continue
    }
    if (line.startsWith('+') || line.startsWith(' ')) {
      lines.add(newLine)
      newLine++
    }
  }
  return lines
}
