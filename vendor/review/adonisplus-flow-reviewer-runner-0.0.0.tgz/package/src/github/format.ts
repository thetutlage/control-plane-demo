/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { SEVERITIES, type Finding } from '../findings.ts'

/** Starts the hidden marker that tells a Flow comment or review from others. */
export const MARKER = '<!-- flow-review '

function marker(data: Record<string, unknown>): string {
  return `${MARKER}${JSON.stringify(data)} -->`
}

/**
 * Splits a Flow comment or review body into its text and the data of its
 * hidden marker. The data is `null` when the body has no marker.
 */
export function readMarker(body: string): { text: string; data: Record<string, any> | null } {
  const start = body.lastIndexOf(MARKER)
  const end = body.indexOf(' -->', start)
  if (start === -1 || end === -1) return { text: body.trim(), data: null }

  try {
    const data = JSON.parse(body.slice(start + MARKER.length, end))
    return { text: body.slice(0, start).trim(), data }
  } catch {
    return { text: body.trim(), data: null }
  }
}

/**
 * A finding outside the diff that is still open. The marker of the last
 * review keeps the list, since such a finding has no thread.
 */
export interface OutsideItem {
  id: string
  path: string
  line: number
  lens: string[]
  refs: string[]
  severity: string
  problem: string
  fix: string
}

/** The counts by severity, such as "1 major, 6 minor". */
export function severityCounts(findings: { severity: string }[]): string {
  const counts = SEVERITIES.map((severity) => ({
    severity,
    count: findings.filter((finding) => finding.severity === severity).length,
  })).filter(({ count }) => count > 0)

  return counts.length
    ? counts.map(({ severity, count }) => `${count} ${severity}`).join(', ')
    : 'no findings'
}

/** The body of the inline comment of a finding, with the files of its lenses in the marker. */
export function commentBody(finding: Finding, refs: string[] = []): string {
  const parts = [
    `**${finding.severity}** · ${finding.lens.map((lens) => `\`${lens}\``).join(', ')}`,
    finding.problem,
    `**Impact:** ${finding.impact}`,
    `**Fix:** ${finding.fix}`,
  ]
  if (finding.suggestion) parts.push(`\`\`\`suggestion\n${finding.suggestion}\n\`\`\``)
  parts.push(
    marker({
      lens: finding.lens,
      refs,
      severity: finding.severity,
      consequence: finding.consequence,
      likelihood: finding.likelihood,
    })
  )
  return parts.join('\n\n')
}

/**
 * The body of the review: the counts, the lens messages, and the findings
 * whose lines are outside the diff. Its marker keeps the head and the
 * findings outside the diff that are still open, for the next re-review.
 */
export function reviewBody(options: {
  findings: Finding[]
  outside: Finding[]
  openOutside: OutsideItem[]
  messages: string[]
  lensesRan: number
  base: string
  head: string
  reReview?: { since: string; resolved: number }
}): string {
  const parts = [
    `**Flow review** · ${severityCounts(options.findings)} · ${options.lensesRan} lenses ran`,
  ]
  if (options.reReview) {
    parts.push(
      `Re-review of ${options.reReview.since.slice(0, 7)}..${options.head.slice(0, 7)} · ${options.reReview.resolved} earlier comment(s) resolved`
    )
  }
  parts.push(...options.messages)

  if (options.outside.length) {
    const items = options.outside.map(
      (finding) =>
        `- \`${finding.path}:${finding.line}\` · **${finding.severity}** · ${finding.problem} **Fix:** ${finding.fix}`
    )
    parts.push(['**Outside the diff**', ...items].join('\n'))
  }

  parts.push(marker({ base: options.base, head: options.head, outside: options.openOutside }))
  return parts.join('\n\n')
}
