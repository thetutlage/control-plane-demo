/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { SEVERITIES, type Finding } from '../findings.ts'

/** Starts the hidden marker that tells a Flow comment or review from others. */
export const MARKER = '<!-- flow-review '

function marker(data: Record<string, unknown>): string {
  return `${MARKER}${JSON.stringify(data)} -->`
}

/** The counts by severity, such as "1 major, 6 minor". */
export function severityCounts(findings: Finding[]): string {
  const counts = SEVERITIES.map((severity) => ({
    severity,
    count: findings.filter((finding) => finding.severity === severity).length,
  })).filter(({ count }) => count > 0)

  return counts.length
    ? counts.map(({ severity, count }) => `${count} ${severity}`).join(', ')
    : 'no findings'
}

/** The body of the inline comment of a finding. */
export function commentBody(finding: Finding): string {
  const parts = [
    `**${finding.severity}** · ${finding.lens.map((lens) => `\`${lens}\``).join(', ')}`,
    finding.problem,
    `**Impact:** ${finding.impact}`,
    `**Fix:** ${finding.fix}`,
  ]
  if (finding.suggestion) parts.push(`\`\`\`suggestion\n${finding.suggestion}\n\`\`\``)
  parts.push(
    marker({
      lens: finding.lens,
      severity: finding.severity,
      consequence: finding.consequence,
      likelihood: finding.likelihood,
    })
  )
  return parts.join('\n\n')
}

/**
 * The body of the review: the counts, the lens messages, and the findings
 * whose lines are outside the diff.
 */
export function reviewBody(options: {
  findings: Finding[]
  outside: Finding[]
  messages: string[]
  lensesRan: number
  base: string
  head: string
}): string {
  const parts = [
    `**Flow review** · ${severityCounts(options.findings)} · ${options.lensesRan} lenses ran`,
    ...options.messages,
  ]

  if (options.outside.length) {
    const items = options.outside.map(
      (finding) =>
        `- \`${finding.path}:${finding.line}\` · **${finding.severity}** · ${finding.problem} **Fix:** ${finding.fix}`
    )
    parts.push(['**Outside the diff**', ...items].join('\n'))
  }

  parts.push(marker({ base: options.base, head: options.head }))
  return parts.join('\n\n')
}
