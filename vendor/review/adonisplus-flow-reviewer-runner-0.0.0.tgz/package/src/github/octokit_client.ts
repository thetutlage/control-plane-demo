/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { Octokit } from '@octokit/rest'

import type { GitHubClient, ReviewComment } from './review_poster.ts'
import type { EarlierReviewClient, ReviewThread } from './earlier_review.ts'

const REVIEW_THREADS = `
  query ($owner: String!, $repo: String!, $pr: Int!, $after: String) {
    repository(owner: $owner, name: $repo) {
      pullRequest(number: $pr) {
        reviewThreads(first: 100, after: $after) {
          pageInfo { hasNextPage endCursor }
          nodes {
            id
            isResolved
            isOutdated
            path
            line
            originalLine
            comments(first: 100) {
              nodes { body author { login __typename } }
            }
          }
        }
      }
    }
  }
`

interface ReviewThreadsPage {
  repository: {
    pullRequest: {
      reviewThreads: {
        pageInfo: { hasNextPage: boolean; endCursor: string | null }
        nodes: {
          id: string
          isResolved: boolean
          isOutdated: boolean
          path: string
          line: number | null
          originalLine: number | null
          comments: {
            nodes: { body: string; author: { login: string; __typename: string } | null }[]
          }
        }[]
      }
    }
  }
}

/** The GitHub calls of a review, made with Octokit on one repository. */
export class OctokitClient implements GitHubClient, EarlierReviewClient {
  #octokit: Octokit

  constructor(
    token: string,
    private owner: string,
    private repo: string
  ) {
    this.#octokit = new Octokit({ auth: token })
  }

  async listFiles(pr: number) {
    const files = await this.#octokit.paginate(this.#octokit.rest.pulls.listFiles, {
      owner: this.owner,
      repo: this.repo,
      pull_number: pr,
      per_page: 100,
    })
    return files.map((file) => ({ filename: file.filename, patch: file.patch }))
  }

  async listReviews(pr: number) {
    const reviews = await this.#octokit.paginate(this.#octokit.rest.pulls.listReviews, {
      owner: this.owner,
      repo: this.repo,
      pull_number: pr,
      per_page: 100,
    })
    return reviews.map((review) => ({ body: review.body, bot: review.user?.type === 'Bot' }))
  }

  /**
   * The review threads of a pull request, from the GraphQL API: only it says
   * if a thread is resolved. An outdated thread has no line, so it takes the
   * line that it had.
   */
  async listReviewThreads(pr: number): Promise<ReviewThread[]> {
    const threads: ReviewThread[] = []
    let after: string | null = null
    do {
      const page: ReviewThreadsPage = await this.#octokit.graphql(REVIEW_THREADS, {
        owner: this.owner,
        repo: this.repo,
        pr,
        after,
      })
      const { pageInfo, nodes } = page.repository.pullRequest.reviewThreads
      for (const node of nodes) {
        threads.push({
          id: node.id,
          resolved: node.isResolved,
          outdated: node.isOutdated,
          path: node.path,
          line: node.line ?? node.originalLine,
          comments: node.comments.nodes.map((comment) => ({
            author: comment.author?.login ?? 'ghost',
            bot: comment.author?.__typename === 'Bot',
            body: comment.body,
          })),
        })
      }
      after = pageInfo.hasNextPage ? pageInfo.endCursor : null
    } while (after)
    return threads
  }

  async createReview(
    pr: number,
    review: { commitId: string; body: string; comments: ReviewComment[] }
  ) {
    await this.#octokit.rest.pulls.createReview({
      owner: this.owner,
      repo: this.repo,
      pull_number: pr,
      commit_id: review.commitId,
      event: 'COMMENT',
      body: review.body,
      comments: review.comments.map((comment) => ({
        path: comment.path,
        line: comment.line,
        side: 'RIGHT' as const,
        ...(comment.startLine
          ? { start_line: comment.startLine, start_side: 'RIGHT' as const }
          : {}),
        body: comment.body,
      })),
    })
  }

  async replyToThread(threadId: string, body: string) {
    await this.#octokit.graphql(
      `mutation ($threadId: ID!, $body: String!) {
        addPullRequestReviewThreadReply(input: { pullRequestReviewThreadId: $threadId, body: $body }) {
          comment { id }
        }
      }`,
      { threadId, body }
    )
  }

  async resolveThread(threadId: string) {
    await this.#octokit.graphql(
      `mutation ($threadId: ID!) {
        resolveReviewThread(input: { threadId: $threadId }) { thread { id } }
      }`,
      { threadId }
    )
  }

  async createCheckRun(check: {
    headSha: string
    conclusion: 'success' | 'failure'
    title: string
    summary: string
  }) {
    await this.#octokit.rest.checks.create({
      owner: this.owner,
      repo: this.repo,
      name: 'Flow review',
      head_sha: check.headSha,
      status: 'completed',
      conclusion: check.conclusion,
      output: { title: check.title, summary: check.summary },
    })
  }
}
