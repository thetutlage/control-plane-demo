/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { Octokit } from '@octokit/rest'

import type { GitHubClient, ReviewComment } from './review_poster.ts'

/** The GitHub calls of a review, made with Octokit on one repository. */
export class OctokitClient implements GitHubClient {
  #octokit: Octokit

  constructor(
    token: string,
    private owner: string,
    private repo: string
  ) {
    this.#octokit = new Octokit({ auth: token })
  }

  async listFiles(pr: number) {
    const files = await this.#octokit.paginate(this.#octokit.rest.pulls.listFiles, {
      owner: this.owner,
      repo: this.repo,
      pull_number: pr,
      per_page: 100,
    })
    return files.map((file) => ({ filename: file.filename, patch: file.patch }))
  }

  async createReview(
    pr: number,
    review: { commitId: string; body: string; comments: ReviewComment[] }
  ) {
    await this.#octokit.rest.pulls.createReview({
      owner: this.owner,
      repo: this.repo,
      pull_number: pr,
      commit_id: review.commitId,
      event: 'COMMENT',
      body: review.body,
      comments: review.comments.map((comment) => ({
        path: comment.path,
        line: comment.line,
        side: 'RIGHT' as const,
        ...(comment.startLine
          ? { start_line: comment.startLine, start_side: 'RIGHT' as const }
          : {}),
        body: comment.body,
      })),
    })
  }

  async createCheckRun(check: {
    headSha: string
    conclusion: 'success' | 'failure'
    title: string
    summary: string
  }) {
    await this.#octokit.rest.checks.create({
      owner: this.owner,
      repo: this.repo,
      name: 'Flow review',
      head_sha: check.headSha,
      status: 'completed',
      conclusion: check.conclusion,
      output: { title: check.title, summary: check.summary },
    })
  }
}
