/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { readMarker } from './format.ts'

/** A review thread of a pull request, as GitHub returns it. */
export interface ReviewThread {
  id: string
  resolved: boolean
  outdated: boolean
  path: string
  line: number | null
  comments: { author: string; bot: boolean; body: string }[]
}

/** The calls to GitHub that reading the earlier review needs. */
export interface EarlierReviewClient {
  listReviews(pr: number): Promise<{ body: string; bot: boolean }[]>
  listReviewThreads(pr: number): Promise<ReviewThread[]>
}

/** One earlier Flow comment, as the code-re-review skill reads it from the threads file. */
export interface ThreadEntry {
  id: string
  path: string
  line: number | null
  outdated: boolean
  refs: string[]
  severity: string
  state: 'open' | 'resolved' | 'outside'
  body: string
  replies: { author: string; body: string }[]
}

export interface EarlierReview {
  /** The head commit that the earlier review reviewed. */
  head: string
  threads: ThreadEntry[]
}

/**
 * Reads the last Flow review of a pull request and the Flow comments on it.
 * A Flow review or comment is one that a bot posted with the hidden marker.
 */
export class EarlierReviewReader {
  constructor(private client: EarlierReviewClient) {}

  /** The last Flow review and its comments, or `null` when Flow has not reviewed the pull request. */
  async read(pr: number): Promise<EarlierReview | null> {
    const reviews = await this.client.listReviews(pr)
    const last = reviews
      .filter((review) => review.bot)
      .map((review) => readMarker(review.body).data)
      .filter((data) => typeof data?.head === 'string')
      .at(-1)
    if (!last) return null

    const threads: ThreadEntry[] = []
    for (const thread of await this.client.listReviewThreads(pr)) {
      const [first, ...replies] = thread.comments
      if (!first?.bot) continue
      const { text, data } = readMarker(first.body)
      if (!data) continue

      threads.push({
        id: thread.id,
        path: thread.path,
        line: thread.line,
        outdated: thread.outdated,
        refs: this.#refs(data),
        severity: String(data.severity),
        state: thread.resolved ? 'resolved' : 'open',
        body: text,
        replies: replies.map((reply) => ({ author: reply.author, body: reply.body })),
      })
    }

    /**
     * The findings outside the diff have no thread. The last review keeps the
     * ones that are still open in its marker.
     */
    for (const item of Array.isArray(last.outside) ? last.outside : []) {
      threads.push({
        id: String(item.id),
        path: String(item.path),
        line: Number.isInteger(item.line) ? item.line : null,
        outdated: false,
        refs: this.#refs(item),
        severity: String(item.severity),
        state: 'outside',
        body: `${item.problem} **Fix:** ${item.fix}`,
        replies: [],
      })
    }

    return { head: last.head, threads }
  }

  /**
   * The lens files of a finding. Its marker names them, else they are the
   * lenses of Flow in `.flow/lenses`.
   */
  #refs(data: Record<string, any>): string[] {
    if (Array.isArray(data.refs)) return data.refs.map(String)
    const lenses: unknown[] = Array.isArray(data.lens) ? data.lens : []
    return lenses.map((lens) => `.flow/lenses/${lens}.md`)
  }
}
