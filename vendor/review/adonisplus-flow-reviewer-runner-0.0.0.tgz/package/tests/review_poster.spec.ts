/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { test } from '@japa/runner'

import type { Finding } from '../src/findings.ts'
import { parseFindings } from '../src/findings.ts'
import { commentableLines } from '../src/github/commentable_lines.ts'
import { commentBody, reviewBody } from '../src/github/format.ts'
import type { ThreadEntry } from '../src/github/earlier_review.ts'
import { ReviewPoster, type GitHubClient } from '../src/github/review_poster.ts'

const PATCH = [
  '@@ -10,4 +10,5 @@ export default class InvoicesController {',
  '   async show({ params }: HttpContext) {',
  '-    const invoice = await auth.user.related("invoices").query()',
  '+    const invoice = await Invoice.findOrFail(params.id)',
  '+    return invoice',
  '   }',
  '@@ -40,2 +41,2 @@',
  '-  old()',
  '+  new()',
].join('\n')

function finding(overrides: Partial<Finding> = {}): Finding {
  return {
    lens: ['review-access-control'],
    severity: 'critical',
    consequence: 'harm',
    likelihood: 'always',
    path: 'app/controllers/invoices_controller.ts',
    line: 11,
    endLine: 12,
    problem: 'Any signed-in user can read the invoice of another tenant.',
    impact: 'Any signed-in user can change the id in the URL.',
    fix: 'Load the invoice through the tenant of the user.',
    ...overrides,
  }
}

/** A GitHub client that records its calls, and can reject the first review. */
function fakeClient(options: { rejectFirstReview?: boolean } = {}) {
  const calls = {
    reviews: [] as any[],
    checks: [] as any[],
    replies: [] as [string, string][],
    resolved: [] as string[],
  }
  let rejected = false
  const client: GitHubClient = {
    listFiles: async () => [
      { filename: 'app/controllers/invoices_controller.ts', patch: PATCH },
      { filename: 'public/logo.png' },
    ],
    createReview: async (pr, review) => {
      if (options.rejectFirstReview && !rejected) {
        rejected = true
        throw Object.assign(new Error('Unprocessable'), { status: 422 })
      }
      calls.reviews.push({ pr, ...review })
    },
    replyToThread: async (threadId, body) => {
      calls.replies.push([threadId, body])
    },
    resolveThread: async (threadId) => {
      calls.resolved.push(threadId)
    },
    createCheckRun: async (check) => {
      calls.checks.push(check)
    },
  }
  return { client, calls }
}

const POST = {
  pr: 7,
  base: 'aaa',
  head: 'bbbbbbbbbb',
  lensesRan: 8,
  refs: new Map([['review-access-control', '.flow/lenses/review-access-control.md']]),
}

function earlierThread(overrides: Partial<ThreadEntry> = {}): ThreadEntry {
  return {
    id: 'PRRT_1',
    path: 'app/controllers/invoices_controller.ts',
    line: 11,
    outdated: false,
    refs: ['.flow/lenses/review-query-cost.md'],
    severity: 'major',
    state: 'open',
    body: 'The filter has no index.',
    replies: [],
    ...overrides,
  }
}

test.group('commentableLines', () => {
  test('returns the added and the context lines of the new file', ({ assert }) => {
    assert.deepEqual([...commentableLines(PATCH)], [10, 11, 12, 13, 41])
  })

  test('returns no lines for a file with no patch', ({ assert }) => {
    assert.equal(commentableLines(undefined).size, 0)
  })
})

test.group('format', () => {
  test('writes the comment of a finding with its hidden marker', ({ assert }) => {
    assert.equal(
      commentBody(finding({ suggestion: '    const invoice = await tenant.related("invoices")' }), [
        '.flow/lenses/review-access-control.md',
      ]),
      [
        '**critical** · `review-access-control`',
        'Any signed-in user can read the invoice of another tenant.',
        '**Impact:** Any signed-in user can change the id in the URL.',
        '**Fix:** Load the invoice through the tenant of the user.',
        '```suggestion\n    const invoice = await tenant.related("invoices")\n```',
        '<!-- flow-review {"lens":["review-access-control"],"refs":[".flow/lenses/review-access-control.md"],"severity":"critical","consequence":"harm","likelihood":"always"} -->',
      ].join('\n\n')
    )
  })

  test('writes the review body with the findings outside the diff', ({ assert }) => {
    const outside = finding({ path: 'app/models/invoice.ts', line: 57, severity: 'minor' })
    assert.equal(
      reviewBody({
        findings: [finding(), outside],
        outside: [outside],
        openOutside: [],
        messages: ['The AdonisJS harness is not installed.'],
        lensesRan: 8,
        base: 'aaa',
        head: 'bbb',
      }),
      [
        '**Flow review** · 1 critical, 1 minor · 8 lenses ran',
        'The AdonisJS harness is not installed.',
        '**Outside the diff**\n- `app/models/invoice.ts:57` · **minor** · Any signed-in user can read the invoice of another tenant. **Fix:** Load the invoice through the tenant of the user.',
        '<!-- flow-review {"base":"aaa","head":"bbb","outside":[]} -->',
      ].join('\n\n')
    )
  })
})

test.group('ReviewPoster', () => {
  test('posts a finding on lines of the diff as an inline comment', async ({ assert }) => {
    const { client, calls } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: { findings: [finding()], messages: [], threads: [] },
    })

    assert.deepInclude(result, { inline: 1, outside: 0, conclusion: 'failure' })
    assert.equal(calls.reviews[0].commitId, 'bbbbbbbbbb')
    assert.deepInclude(calls.reviews[0].comments[0], {
      path: 'app/controllers/invoices_controller.ts',
      line: 12,
      startLine: 11,
    })
  })

  test('puts a finding outside the diff in the review body', async ({ assert }) => {
    const { client, calls } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [finding({ line: 30, endLine: 30, severity: 'minor' })],
        messages: [],
        threads: [],
      },
    })

    assert.deepInclude(result, { inline: 0, outside: 1, conclusion: 'success' })
    assert.lengthOf(calls.reviews[0].comments, 0)
    assert.include(calls.reviews[0].body, '**Outside the diff**')
  })

  test('puts a finding whose lines are only partly in the diff in the body', async ({ assert }) => {
    const { client } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: { findings: [finding({ line: 13, endLine: 15 })], messages: [], threads: [] },
    })

    assert.equal(result.outside, 1)
  })

  test('posts every finding in the body when GitHub rejects a comment', async ({ assert }) => {
    const { client, calls } = fakeClient({ rejectFirstReview: true })
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: { findings: [finding()], messages: [], threads: [] },
    })

    assert.deepInclude(result, { inline: 0, outside: 1, conclusion: 'failure' })
    assert.lengthOf(calls.reviews, 1)
    assert.lengthOf(calls.reviews[0].comments, 0)
  })

  test('fails the check run on a major finding and passes it on minor ones', async ({ assert }) => {
    const failing = fakeClient()
    await new ReviewPoster(failing.client).post({
      ...POST,
      file: { findings: [finding({ severity: 'major' })], messages: [], threads: [] },
    })
    assert.equal(failing.calls.checks[0].conclusion, 'failure')
    assert.equal(failing.calls.checks[0].headSha, 'bbbbbbbbbb')

    const passing = fakeClient()
    await new ReviewPoster(passing.client).post({
      ...POST,
      file: { findings: [finding({ severity: 'minor' })], messages: [], threads: [] },
    })
    assert.equal(passing.calls.checks[0].conclusion, 'success')
  })
})

test.group('ReviewPoster re-review', () => {
  test('replies to and resolves each earlier comment that is fixed', async ({ assert }) => {
    const { client, calls } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [],
        messages: [],
        threads: [{ id: 'PRRT_1', fixed: true, reason: 'A migration adds the index.' }],
      },
      earlier: { since: 'cccccccccc', threads: [earlierThread()] },
    })

    assert.deepEqual(calls.replies, [
      ['PRRT_1', 'Addressed in bbbbbbb. A migration adds the index.'],
    ])
    assert.deepEqual(calls.resolved, ['PRRT_1'])
    assert.include(
      calls.reviews[0].body,
      'Re-review of ccccccc..bbbbbbb · 1 earlier comment(s) resolved'
    )
    assert.deepInclude(result, { resolved: 1, undecided: [], conclusion: 'success' })
  })

  test('posts the review when GitHub does not let the token resolve a thread', async ({
    assert,
  }) => {
    const { client, calls } = fakeClient()
    client.resolveThread = async () => {
      throw new Error('Resource not accessible by integration')
    }
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [],
        messages: [],
        threads: [{ id: 'PRRT_1', fixed: true, reason: 'A migration adds the index.' }],
      },
      earlier: { since: 'cccccccccc', threads: [earlierThread()] },
    })

    assert.deepEqual(result.unresolved, [
      { id: 'PRRT_1', error: 'Resource not accessible by integration' },
    ])
    assert.lengthOf(calls.reviews, 1)
    assert.lengthOf(calls.checks, 1)
  })

  test('does not reply again to a thread that has a reply from an earlier run', async ({
    assert,
  }) => {
    const { client, calls } = fakeClient()
    await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [],
        messages: [],
        threads: [{ id: 'PRRT_1', fixed: true, reason: 'A migration adds the index.' }],
      },
      earlier: {
        since: 'cccccccccc',
        threads: [
          earlierThread({
            replies: [{ author: 'github-actions', body: 'Addressed in e75de6d. The index.' }],
          }),
        ],
      },
    })

    assert.deepEqual(calls.replies, [])
    assert.deepEqual(calls.resolved, ['PRRT_1'])
  })

  test('fails the check run while an earlier major comment is open', async ({ assert }) => {
    const { client, calls } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [],
        messages: [],
        threads: [{ id: 'PRRT_1', fixed: false, reason: 'The index is still missing.' }],
      },
      earlier: {
        since: 'cccccccccc',
        threads: [earlierThread(), earlierThread({ id: 'PRRT_2', state: 'resolved' })],
      },
    })

    assert.deepEqual(calls.resolved, [])
    assert.equal(result.conclusion, 'failure')
    assert.equal(calls.checks[0].title, '1 major open')
  })

  test('keeps an earlier comment with no decision open', async ({ assert }) => {
    const { client, calls } = fakeClient()
    const result = await new ReviewPoster(client).post({
      ...POST,
      file: { findings: [], messages: [], threads: [] },
      earlier: { since: 'cccccccccc', threads: [earlierThread()] },
    })

    assert.deepEqual(result.undecided, ['PRRT_1'])
    assert.deepEqual(calls.resolved, [])
    assert.equal(result.conclusion, 'failure')
  })

  test('keeps the open findings outside the diff in the marker', async ({ assert }) => {
    const { client, calls } = fakeClient()
    await new ReviewPoster(client).post({
      ...POST,
      file: {
        findings: [finding({ line: 30, endLine: 30, severity: 'minor' })],
        messages: [],
        threads: [
          { id: 'outside-1', fixed: true, reason: 'Fixed.' },
          { id: 'outside-2', fixed: false, reason: 'Still there.' },
        ],
      },
      earlier: {
        since: 'cccccccccc',
        threads: [
          earlierThread({ id: 'outside-1', state: 'outside', body: 'One. **Fix:** Do one.' }),
          earlierThread({ id: 'outside-2', state: 'outside', body: 'Two. **Fix:** Do two.' }),
        ],
      },
    })

    const marker = JSON.parse(calls.reviews[0].body.match(/<!-- flow-review (.*) -->/)[1])
    assert.deepEqual(
      marker.outside.map((item: any) => [item.id, item.problem, item.fix, item.refs]),
      [
        ['outside-2', 'Two.', 'Do two.', ['.flow/lenses/review-query-cost.md']],
        [
          'outside-bbbbbbb-1',
          finding().problem,
          finding().fix,
          ['.flow/lenses/review-access-control.md'],
        ],
      ]
    )
    assert.include(calls.reviews[0].body, '1 earlier comment(s) resolved')
  })
})

test.group('parseFindings', () => {
  test('reads the findings and the messages', ({ assert }) => {
    const file = parseFindings({ findings: [finding()], messages: ['No harness'], dropped: [] })
    assert.lengthOf(file.findings, 1)
    assert.deepEqual(file.messages, ['No harness'])
  })

  test('fails on an unknown severity', ({ assert }) => {
    assert.throws(
      () => parseFindings({ findings: [finding({ severity: 'high' as any })] }),
      'findings[0] has an unknown severity "high"'
    )
  })
})
