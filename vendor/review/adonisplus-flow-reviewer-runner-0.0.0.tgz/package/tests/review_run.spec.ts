/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { test } from '@japa/runner'
import type { FileSystem } from '@japa/file-system'
import type { SDKResultMessage } from '@anthropic-ai/claude-agent-sdk'

import { ReviewRun, ReviewRunError, type QueryFn } from '../src/review_run.ts'

const FINDINGS = { findings: [{ lens: ['review-tests'], severity: 'minor' }] }

const USAGE = {
  inputTokens: 100,
  outputTokens: 50,
  cacheReadInputTokens: 2000,
  cacheCreationInputTokens: 300,
  webSearchRequests: 0,
  costUSD: 0.4,
  contextWindow: 200000,
  maxOutputTokens: 32000,
}

function result(overrides: Record<string, unknown> = {}) {
  return {
    type: 'result',
    subtype: 'success',
    duration_ms: 90000,
    num_turns: 12,
    total_cost_usd: 0.55,
    modelUsage: { 'claude-opus-5-5': USAGE, 'claude-sonnet-5-5': { ...USAGE, costUSD: 0.15 } },
    errors: [],
    ...overrides,
  } as unknown as SDKResultMessage
}

/**
 * A query that records its params and, like the skill, writes the findings
 * file before it yields the result.
 */
function fakeQuery(fs: FileSystem, message: SDKResultMessage, findings?: string) {
  const calls: Parameters<QueryFn>[0][] = []
  const fn = ((params: Parameters<QueryFn>[0]) => {
    calls.push(params)
    return (async function* () {
      if (findings !== undefined) await fs.create('tmp/code-review.json', findings)
      yield message
    })()
  }) as unknown as QueryFn
  return { fn, calls }
}

const RUN = { base: 'main', head: 'feature', maxBudgetUsd: 5 }

test.group('ReviewRun', () => {
  test('runs the code-review skill on the diff', async ({ assert, fs }) => {
    const query = fakeQuery(fs, result(), JSON.stringify(FINDINGS))
    await new ReviewRun(query.fn).run({ ...RUN, cwd: fs.basePath })

    assert.equal(
      query.calls[0].prompt,
      '/flow-code-review Review the diff between main and feature. Do not print the findings.'
    )
    assert.include(query.calls[0].options!, {
      cwd: fs.basePath,
      model: 'opus',
      permissionMode: 'dontAsk',
      maxBudgetUsd: 5,
    })
    assert.deepEqual(query.calls[0].options!.settingSources, ['project'])
    assert.equal(query.calls[0].options!.env!.CLAUDE_CODE_DISABLE_BACKGROUND_TASKS, '1')
  })

  test('returns the findings and the cost of each model', async ({ assert, fs }) => {
    const query = fakeQuery(fs, result(), JSON.stringify(FINDINGS))
    const output = await new ReviewRun(query.fn).run({ ...RUN, cwd: fs.basePath })

    assert.deepEqual(output.findings, FINDINGS)
    assert.equal(output.cost.totalCostUsd, 0.55)
    assert.deepEqual(output.cost.models[1], {
      model: 'claude-sonnet-5-5',
      costUsd: 0.15,
      inputTokens: 100,
      outputTokens: 50,
      cacheReadInputTokens: 2000,
      cacheCreationInputTokens: 300,
    })
  })

  test('fails with the cost when the run fails', async ({ assert, fs }) => {
    const query = fakeQuery(
      fs,
      result({ subtype: 'error_max_budget_usd', errors: ['Budget reached'] })
    )

    try {
      await new ReviewRun(query.fn).run({ ...RUN, cwd: fs.basePath })
      assert.fail('The run must fail')
    } catch (error) {
      assert.instanceOf(error, ReviewRunError)
      assert.equal(
        (error as ReviewRunError).message,
        'The review failed with error_max_budget_usd: Budget reached'
      )
      assert.equal((error as ReviewRunError).cost?.totalCostUsd, 0.55)
    }
  })

  test('removes the findings of an earlier run before it starts', async ({ assert, fs }) => {
    await fs.create('tmp/code-review.json', JSON.stringify(FINDINGS))
    const query = fakeQuery(fs, result())

    await assert.rejects(
      () => new ReviewRun(query.fn).run({ ...RUN, cwd: fs.basePath }),
      'The review did not write tmp/code-review.json'
    )
  })

  test('fails when the findings file is not JSON', async ({ assert, fs }) => {
    const query = fakeQuery(fs, result(), 'findings: []')

    await assert.rejects(
      () => new ReviewRun(query.fn).run({ ...RUN, cwd: fs.basePath }),
      'tmp/code-review.json is not valid JSON'
    )
  })
})
