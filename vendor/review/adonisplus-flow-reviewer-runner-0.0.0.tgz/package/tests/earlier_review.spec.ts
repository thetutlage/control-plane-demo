/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { test } from '@japa/runner'

import { readMarker } from '../src/github/format.ts'
import {
  EarlierReviewReader,
  type EarlierReviewClient,
  type ReviewThread,
} from '../src/github/earlier_review.ts'

const FLOW_COMMENT = [
  '**major** · `review-query-cost`',
  'The filter has no index.',
  '<!-- flow-review {"lens":["review-query-cost"],"severity":"major"} -->',
].join('\n\n')

function thread(overrides: Partial<ReviewThread> = {}): ReviewThread {
  return {
    id: 'PRRT_1',
    resolved: false,
    outdated: false,
    path: 'app/controllers/audit_logs_controller.ts',
    line: 26,
    comments: [{ author: 'github-actions', bot: true, body: FLOW_COMMENT }],
    ...overrides,
  }
}

function fakeClient(
  reviews: { body: string; bot: boolean }[],
  threads: ReviewThread[] = []
): EarlierReviewClient {
  return { listReviews: async () => reviews, listReviewThreads: async () => threads }
}

const flowReview = (data: Record<string, unknown>) => ({
  body: `**Flow review** · 1 major\n\n<!-- flow-review ${JSON.stringify(data)} -->`,
  bot: true,
})

test.group('readMarker', () => {
  test('splits a body into its text and the data of its marker', ({ assert }) => {
    assert.deepEqual(readMarker(FLOW_COMMENT), {
      text: '**major** · `review-query-cost`\n\nThe filter has no index.',
      data: { lens: ['review-query-cost'], severity: 'major' },
    })
  })

  test('returns no data for a body with no marker', ({ assert }) => {
    assert.deepEqual(readMarker('Looks good'), { text: 'Looks good', data: null })
  })
})

test.group('EarlierReviewReader', () => {
  test('returns null when Flow has not reviewed the pull request', async ({ assert }) => {
    const client = fakeClient([
      { body: 'LGTM', bot: false },
      { body: 'Nice', bot: true },
    ])
    assert.isNull(await new EarlierReviewReader(client).read(7))
  })

  test('takes the head of the last Flow review', async ({ assert }) => {
    const client = fakeClient([
      flowReview({ base: 'aaa', head: 'bbb' }),
      { body: 'Fixed it', bot: false },
      flowReview({ base: 'aaa', head: 'ccc' }),
    ])
    const earlier = await new EarlierReviewReader(client).read(7)
    assert.equal(earlier?.head, 'ccc')
  })

  test('reads the Flow threads with their state and replies', async ({ assert }) => {
    const client = fakeClient(
      [flowReview({ base: 'aaa', head: 'bbb' })],
      [
        thread({
          comments: [
            { author: 'github-actions', bot: true, body: FLOW_COMMENT },
            { author: 'virk', bot: false, body: 'The table is small.' },
          ],
        }),
        thread({ id: 'PRRT_2', resolved: true, outdated: true, line: 20 }),
      ]
    )
    const earlier = await new EarlierReviewReader(client).read(7)

    assert.deepEqual(earlier?.threads, [
      {
        id: 'PRRT_1',
        path: 'app/controllers/audit_logs_controller.ts',
        line: 26,
        outdated: false,
        refs: ['.flow/lenses/review-query-cost.md'],
        severity: 'major',
        state: 'open',
        body: '**major** · `review-query-cost`\n\nThe filter has no index.',
        replies: [{ author: 'virk', body: 'The table is small.' }],
      },
      {
        id: 'PRRT_2',
        path: 'app/controllers/audit_logs_controller.ts',
        line: 20,
        outdated: true,
        refs: ['.flow/lenses/review-query-cost.md'],
        severity: 'major',
        state: 'resolved',
        body: '**major** · `review-query-cost`\n\nThe filter has no index.',
        replies: [],
      },
    ])
  })

  test('leaves out the threads that a person started', async ({ assert }) => {
    const client = fakeClient(
      [flowReview({ base: 'aaa', head: 'bbb' })],
      [
        thread({ comments: [{ author: 'virk', bot: false, body: FLOW_COMMENT }] }),
        thread({ comments: [{ author: 'other-bot', bot: true, body: 'Typo here.' }] }),
      ]
    )
    const earlier = await new EarlierReviewReader(client).read(7)
    assert.deepEqual(earlier?.threads, [])
  })

  test('reads the open findings outside the diff from the last review', async ({ assert }) => {
    const client = fakeClient([
      flowReview({
        base: 'aaa',
        head: 'bbb',
        outside: [
          {
            id: 'outside-1',
            path: 'app/models/audit_event.ts',
            line: 12,
            lens: ['review-tests'],
            refs: ['review-lenses/tests.md'],
            severity: 'minor',
            problem: 'No test covers the filter.',
            fix: 'Add a test.',
          },
        ],
      }),
    ])
    const earlier = await new EarlierReviewReader(client).read(7)

    assert.deepEqual(earlier?.threads, [
      {
        id: 'outside-1',
        path: 'app/models/audit_event.ts',
        line: 12,
        outdated: false,
        refs: ['review-lenses/tests.md'],
        severity: 'minor',
        state: 'outside',
        body: 'No test covers the filter. **Fix:** Add a test.',
        replies: [],
      },
    ])
  })
})
