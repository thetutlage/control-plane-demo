/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { test } from '@japa/runner'
import { Kernel } from '@adonisjs/ace'

import RunReview from '../commands/run.ts'
import { type ReviewRun, ReviewRunError, type ReviewRunOptions } from '../src/review_run.ts'

const COST = {
  totalCostUsd: 1.05,
  durationMs: 150000,
  numTurns: 20,
  models: [
    {
      model: 'claude-opus-5-5',
      costUsd: 0.54,
      inputTokens: 10,
      outputTokens: 5000,
      cacheReadInputTokens: 400000,
      cacheCreationInputTokens: 50000,
    },
  ],
}

async function createCommand(argv: string[], review: Partial<ReviewRun>) {
  const kernel = Kernel.create()
  kernel.ui.switchMode('raw')
  const command = await kernel.create(RunReview, argv)
  command.review = review as ReviewRun
  return command
}

test.group('flow-reviewer run', () => {
  test('prints the findings and the cost', async ({ assert }) => {
    const runs: ReviewRunOptions[] = []
    const command = await createCommand(['main', 'feature', '--cwd=/repo', '--max-budget=2'], {
      run: async (options) => {
        runs.push(options)
        return { findings: { findings: [] }, cost: COST }
      },
    })
    await command.exec()

    command.assertSucceeded()
    assert.deepEqual(runs, [{ cwd: '/repo', base: 'main', head: 'feature', maxBudgetUsd: 2 }])
    const output = command.ui.logger.getLogs().map((log) => log.message)
    assert.equal(output[0], JSON.stringify({ findings: [] }, null, 2))
    assert.isTrue(output.some((line) => line.includes('claude-opus-5-5') && line.includes('$0.54')))
  })

  test('prints the cost of a failed run', async ({ assert }) => {
    const command = await createCommand(['main', 'feature'], {
      run: async () => {
        throw new ReviewRunError('The review failed with error_max_turns', COST)
      },
    })
    await command.exec()

    command.assertFailed()
    const output = command.ui.logger.getLogs().map((log) => log.message)
    assert.isTrue(output.some((line) => line.includes('error_max_turns')))
    assert.isTrue(output.some((line) => line.includes('$1.05')))
  })
})

test.group('flow-reviewer run --post', (group) => {
  group.each.setup(() => {
    const env = { token: process.env.GITHUB_TOKEN, repository: process.env.GITHUB_REPOSITORY }
    return () => {
      process.env.GITHUB_TOKEN = env.token
      process.env.GITHUB_REPOSITORY = env.repository
    }
  })

  test('fails before the review when the token or the pr is missing', async ({ assert }) => {
    delete process.env.GITHUB_TOKEN
    process.env.GITHUB_REPOSITORY = 'acme/app'
    let reviewed = false
    const command = await createCommand(['main', 'feature', '--post'], {
      run: async () => {
        reviewed = true
        return { findings: { findings: [] }, cost: COST }
      },
    })
    await command.exec()

    command.assertFailed()
    assert.isFalse(reviewed)
    assert.isTrue(
      command.ui.logger
        .getLogs()
        .some((log) => log.message.includes('--post needs GITHUB_TOKEN, --pr'))
    )
  })
})
