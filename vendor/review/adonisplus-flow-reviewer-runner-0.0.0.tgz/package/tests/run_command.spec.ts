/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { test } from '@japa/runner'
import { promisify } from 'node:util'
import { Kernel } from '@adonisjs/ace'
import { execFile } from 'node:child_process'
import type { FileSystem } from '@japa/file-system'

import RunReview from '../commands/run.ts'
import type { GitHubClient } from '../src/github/review_poster.ts'
import type { EarlierReviewClient } from '../src/github/earlier_review.ts'
import { type ReviewRun, ReviewRunError, type ReviewRunOptions } from '../src/review_run.ts'

const run = promisify(execFile)

async function git(fs: FileSystem, ...args: string[]) {
  const { stdout } = await run('git', args, { cwd: fs.basePath })
  return stdout.trim()
}

/** A repo with two commits on `main`. Returns the sha of each. */
async function createRepo(fs: FileSystem) {
  await fs.create('app/a.ts', 'a\n')
  await git(fs, 'init', '-q', '-b', 'main')
  await git(fs, 'config', 'user.email', 'test@example.com')
  await git(fs, 'config', 'user.name', 'Test')
  await git(fs, 'add', '.')
  await git(fs, 'commit', '-q', '-m', 'first')
  const first = await git(fs, 'rev-parse', 'HEAD')
  await fs.create('app/a.ts', 'b\n')
  await git(fs, 'commit', '-q', '-am', 'second')
  return { first, second: await git(fs, 'rev-parse', 'HEAD') }
}

/** A GitHub client with one earlier Flow review of a head, and one Flow thread. */
function earlierClient(head: string): GitHubClient & EarlierReviewClient {
  const marker = (data: unknown) => `<!-- flow-review ${JSON.stringify(data)} -->`
  return {
    listReviews: async () => [{ body: marker({ base: 'aaa', head }), bot: true }],
    listReviewThreads: async () => [
      {
        id: 'PRRT_1',
        resolved: false,
        outdated: false,
        path: 'app/a.ts',
        line: 1,
        comments: [
          {
            author: 'github-actions',
            bot: true,
            body: `No index.\n\n${marker({ lens: ['review-query-cost'], severity: 'major' })}`,
          },
        ],
      },
    ],
    listFiles: async () => [],
    createReview: async () => {},
    replyToThread: async () => {},
    resolveThread: async () => {},
    createCheckRun: async () => {},
  }
}

const COST = {
  totalCostUsd: 1.05,
  durationMs: 150000,
  numTurns: 20,
  models: [
    {
      model: 'claude-opus-5-5',
      costUsd: 0.54,
      inputTokens: 10,
      outputTokens: 5000,
      cacheReadInputTokens: 400000,
      cacheCreationInputTokens: 50000,
    },
  ],
}

async function createCommand(argv: string[], review: Partial<ReviewRun>) {
  const kernel = Kernel.create()
  kernel.ui.switchMode('raw')
  const command = await kernel.create(RunReview, argv)
  command.review = review as ReviewRun
  return command
}

test.group('flow-reviewer run', () => {
  test('prints the findings and the cost', async ({ assert }) => {
    const runs: ReviewRunOptions[] = []
    const command = await createCommand(['main', 'feature', '--cwd=/repo', '--max-budget=2'], {
      run: async (options) => {
        runs.push(options)
        return { findings: { findings: [] }, cost: COST }
      },
    })
    await command.exec()

    command.assertSucceeded()
    const [{ onStart, ...options }] = runs
    assert.deepEqual(options, { cwd: '/repo', base: 'main', head: 'feature', maxBudgetUsd: 2 })
    assert.isFunction(onStart)
    const output = command.ui.logger.getLogs().map((log) => log.message)
    assert.equal(output[0], JSON.stringify({ findings: [] }, null, 2))
    assert.isTrue(output.some((line) => line.includes('claude-opus-5-5') && line.includes('$0.54')))
  })

  test('prints the cost of a failed run', async ({ assert }) => {
    const command = await createCommand(['main', 'feature'], {
      run: async () => {
        throw new ReviewRunError('The review failed with error_max_turns', COST)
      },
    })
    await command.exec()

    command.assertFailed()
    const output = command.ui.logger.getLogs().map((log) => log.message)
    assert.isTrue(output.some((line) => line.includes('error_max_turns')))
    assert.isTrue(output.some((line) => line.includes('$1.05')))
  })
})

test.group('flow-reviewer run --post', (group) => {
  group.each.setup(() => {
    const env = { token: process.env.GITHUB_TOKEN, repository: process.env.GITHUB_REPOSITORY }
    return () => {
      process.env.GITHUB_TOKEN = env.token
      process.env.GITHUB_REPOSITORY = env.repository
    }
  })

  test('fails before the review when the token or the pr is missing', async ({ assert }) => {
    delete process.env.GITHUB_TOKEN
    process.env.GITHUB_REPOSITORY = 'acme/app'
    let reviewed = false
    const command = await createCommand(['main', 'feature', '--post'], {
      run: async () => {
        reviewed = true
        return { findings: { findings: [] }, cost: COST }
      },
    })
    await command.exec()

    command.assertFailed()
    assert.isFalse(reviewed)
    assert.isTrue(
      command.ui.logger
        .getLogs()
        .some((log) => log.message.includes('--post needs GITHUB_TOKEN, --pr'))
    )
  })

  test('re-reviews the changes after the earlier Flow review', async ({ assert, fs }) => {
    process.env.GITHUB_TOKEN = 'token'
    process.env.GITHUB_REPOSITORY = 'acme/app'
    const { first } = await createRepo(fs)
    const runs: ReviewRunOptions[] = []
    const command = await createCommand(
      [first, 'main', '--post', '--pr=7', `--cwd=${fs.basePath}`],
      {
        run: async (options) => {
          runs.push(options)
          return { findings: { findings: [] }, cost: COST }
        },
      }
    )
    command.createClient = () => earlierClient(first)
    command.planLenses = async () => [{ lens: 'review-query-cost', ref: '.flow/lenses/x.md' }]
    await command.exec()

    command.assertSucceeded()

    assert.deepEqual(runs[0].reReview, {
      since: first,
      threadsFile: 'tmp/flow-review-threads.json',
    })
    const threads = JSON.parse(await fs.contents('tmp/flow-review-threads.json')).threads
    assert.deepEqual(
      threads.map((entry: any) => [entry.id, entry.state, entry.refs]),
      [['PRRT_1', 'open', ['.flow/lenses/review-query-cost.md']]]
    )
  })

  test('skips the review when Flow already reviewed the head', async ({ assert, fs }) => {
    process.env.GITHUB_TOKEN = 'token'
    process.env.GITHUB_REPOSITORY = 'acme/app'
    const { first, second } = await createRepo(fs)
    let reviewed = false
    const command = await createCommand(
      [first, 'main', '--post', '--pr=7', `--cwd=${fs.basePath}`],
      {
        run: async () => {
          reviewed = true
          return { findings: { findings: [] }, cost: COST }
        },
      }
    )
    command.createClient = () => earlierClient(second)
    await command.exec()

    command.assertSucceeded()
    assert.isFalse(reviewed)
    command.assertLog(`[ blue(info) ] Flow already reviewed ${second}`)
  })
})
