/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { resolve } from 'node:path'
import { BaseCommand, args, flags } from '@adonisjs/ace'

import { parseFindings } from '../src/findings.ts'
import { plannedLenses, resolveCommit } from '../src/git.ts'
import { ReviewPoster } from '../src/github/review_poster.ts'
import { OctokitClient } from '../src/github/octokit_client.ts'
import { ReviewRun, ReviewRunError, type ReviewCost } from '../src/review_run.ts'

export default class RunReview extends BaseCommand {
  static commandName = 'run'
  static description =
    'Review the diff between a base and a head, then print the findings and the cost. With --post, post them to the pull request'

  @args.string({ description: 'The base commit or branch' })
  declare base: string

  @args.string({ description: 'The head commit or branch' })
  declare head: string

  @flags.string({ description: 'The repo to review. Defaults to the current directory' })
  declare cwd?: string

  @flags.number({ description: 'Stop the review when its cost reaches this many US dollars' })
  declare maxBudget?: number

  @flags.boolean({
    description:
      'Post the findings as a review of the pull request, with a check run. Reads GITHUB_TOKEN and GITHUB_REPOSITORY',
  })
  declare post?: boolean

  @flags.number({ description: 'The number of the pull request to post to' })
  declare pr?: number

  /** Runs the review. Tests replace it to keep the model out. */
  review = new ReviewRun()

  /** Builds the poster of a repository. Tests replace it to keep GitHub out. */
  createPoster = (token: string, owner: string, repo: string) =>
    new ReviewPoster(new OctokitClient(token, owner, repo))

  async run() {
    const cwd = resolve(this.cwd ?? process.cwd())
    const target = this.post ? this.#postTarget() : null
    if (this.post && !target) return

    try {
      const result = await this.review.run({
        cwd,
        base: this.base,
        head: this.head,
        maxBudgetUsd: this.maxBudget ?? 5,
      })
      this.logger.log(JSON.stringify(result.findings, null, 2))
      this.#printCost(result.cost)

      if (target) {
        const [base, head] = await Promise.all([
          resolveCommit(cwd, this.base),
          resolveCommit(cwd, this.head),
        ])
        const posted = await this.createPoster(target.token, target.owner, target.repo).post({
          pr: this.pr!,
          base,
          head,
          lensesRan: await plannedLenses(cwd, base, head),
          file: parseFindings(result.findings),
        })
        this.logger.success(
          `Posted ${posted.inline} inline comment(s) and ${posted.outside} outside the diff. Check run: ${posted.conclusion}`
        )
      }
    } catch (error) {
      this.logger.error((error as Error).message)
      if (error instanceof ReviewRunError && error.cost) this.#printCost(error.cost)
      this.exitCode = 1
    }
  }

  /**
   * The token and the repository to post to, from the environment that
   * GitHub Actions sets. Fails before the review starts when one is missing,
   * so a run is not paid for and then lost.
   */
  #postTarget(): { token: string; owner: string; repo: string } | null {
    const token = process.env.GITHUB_TOKEN
    const [owner, repo] = (process.env.GITHUB_REPOSITORY ?? '').split('/')
    const missing = [
      !token && 'GITHUB_TOKEN',
      !(owner && repo) && 'GITHUB_REPOSITORY',
      !this.pr && '--pr',
    ].filter(Boolean)

    if (missing.length) {
      this.logger.error(`--post needs ${missing.join(', ')}`)
      this.exitCode = 1
      return null
    }
    return { token: token!, owner, repo }
  }

  #printCost(cost: ReviewCost) {
    const table = this.ui
      .table()
      .head(['Model', 'Cost', 'Input', 'Output', 'Cache read', 'Cache write'])
    for (const model of cost.models) {
      table.row([
        model.model,
        `$${model.costUsd.toFixed(2)}`,
        String(model.inputTokens),
        String(model.outputTokens),
        String(model.cacheReadInputTokens),
        String(model.cacheCreationInputTokens),
      ])
    }
    table.row(['Total', `$${cost.totalCostUsd.toFixed(2)}`, '', '', '', ''])
    table.render()
    this.logger.info(`${cost.numTurns} turns in ${(cost.durationMs / 1000).toFixed(0)}s`)
  }
}
