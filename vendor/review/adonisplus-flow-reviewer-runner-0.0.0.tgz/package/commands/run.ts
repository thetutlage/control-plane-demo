/*
 * @adonisplus/flow-reviewer-runner
 *
 * (c) AdonisJS Plus
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import { join, resolve } from 'node:path'
import { mkdir, writeFile } from 'node:fs/promises'
import { BaseCommand, args, flags } from '@adonisjs/ace'

import { parseFindings } from '../src/findings.ts'
import { OctokitClient } from '../src/github/octokit_client.ts'
import { fetchCommit, mergeBase, plannedLenses, resolveCommit } from '../src/git.ts'
import { ReviewPoster, type GitHubClient } from '../src/github/review_poster.ts'
import {
  EarlierReviewReader,
  type EarlierReviewClient,
  type ThreadEntry,
} from '../src/github/earlier_review.ts'
import { ReviewRun, ReviewRunError, THREADS_FILE, type ReviewCost } from '../src/review_run.ts'

export default class RunReview extends BaseCommand {
  static commandName = 'run'
  static description =
    'Review the diff between a base and a head, then print the findings and the cost. With --post, post them to the pull request'

  @args.string({ description: 'The base commit or branch' })
  declare base: string

  @args.string({ description: 'The head commit or branch' })
  declare head: string

  @flags.string({ description: 'The repo to review. Defaults to the current directory' })
  declare cwd?: string

  @flags.number({ description: 'Stop the review when its cost reaches this many US dollars' })
  declare maxBudget?: number

  @flags.boolean({
    description:
      'Post the findings as a review of the pull request, with a check run. Reads GITHUB_TOKEN and GITHUB_REPOSITORY',
  })
  declare post?: boolean

  @flags.number({ description: 'The number of the pull request to post to' })
  declare pr?: number

  /** Runs the review. Tests replace it to keep the model out. */
  review = new ReviewRun()

  /** Plans the lenses of a diff with Flow. Tests replace it to keep npx out. */
  planLenses = plannedLenses

  /** Builds the GitHub client of a repository. Tests replace it to keep GitHub out. */
  createClient = (token: string, owner: string, repo: string): GitHubClient & EarlierReviewClient =>
    new OctokitClient(token, owner, repo)

  async run() {
    const cwd = resolve(this.cwd ?? process.cwd())
    const target = this.post ? this.#postTarget() : null
    if (this.post && !target) return
    const client = target ? this.createClient(target.token, target.owner, target.repo) : null

    try {
      const earlier = client ? await this.#reReview(cwd, client) : undefined
      if (earlier === 'skip') return

      const result = await this.review.run({
        cwd,
        base: this.base,
        head: this.head,
        maxBudgetUsd: this.maxBudget ?? 5,
        ...(earlier ? { reReview: { since: earlier.since, threadsFile: THREADS_FILE } } : {}),
        onStart: ({ apiKeySource, model }) => {
          const credential =
            apiKeySource === 'none' ? 'a Claude subscription login or OAuth token' : apiKeySource
          this.logger.info(`Reviewing with ${model}, billed to ${credential}`)
        },
      })
      this.logger.log(JSON.stringify(result.findings, null, 2))
      this.#printCost(result.cost)

      if (client) {
        const [base, head] = await Promise.all([
          resolveCommit(cwd, this.base),
          resolveCommit(cwd, this.head),
        ])
        const lenses = await this.planLenses(cwd, base, head, earlier?.since)
        const posted = await new ReviewPoster(client).post({
          pr: this.pr!,
          base,
          head,
          lensesRan: lenses.length,
          refs: new Map(lenses.map((lens) => [lens.lens, lens.ref])),
          file: parseFindings(result.findings),
          ...(earlier ? { earlier } : {}),
        })
        for (const thread of posted.unresolved) {
          this.logger.warning(
            `Cannot resolve the fixed thread ${thread.id}: ${thread.error}. Resolving a thread needs the contents: write permission`
          )
        }
        if (posted.undecided.length) {
          this.logger.warning(
            `The re-review gave no decision on ${posted.undecided.length} earlier comment(s), so they stay open: ${posted.undecided.join(', ')}`
          )
        }
        this.logger.success(
          `Posted ${posted.inline} inline comment(s) and ${posted.outside} outside the diff. Resolved ${posted.resolved} earlier comment(s). Check run: ${posted.conclusion}`
        )
      }
    } catch (error) {
      this.logger.error((error as Error).message)
      if (error instanceof ReviewRunError && error.cost) this.#printCost(error.cost)
      this.exitCode = 1
    }
  }

  /**
   * Prepares a re-review when Flow reviewed the pull request before: fetches
   * the commit of that review and writes the threads file. Returns `skip`
   * when Flow already reviewed the head. When GitHub no longer has the commit
   * of the earlier review, the re-review covers the whole pull request.
   */
  async #reReview(
    cwd: string,
    client: EarlierReviewClient
  ): Promise<{ since: string; threads: ThreadEntry[] } | 'skip' | undefined> {
    const earlier = await new EarlierReviewReader(client).read(this.pr!)
    if (!earlier) return undefined

    const head = await resolveCommit(cwd, this.head)
    if (earlier.head === head) {
      this.logger.info(`Flow already reviewed ${head}`)
      return 'skip'
    }

    let since = earlier.head
    if (!(await fetchCommit(cwd, since))) {
      since = await mergeBase(cwd, this.base, this.head)
      this.logger.warning(
        `Cannot fetch ${earlier.head}, the commit of the earlier review. Re-reviewing the whole pull request`
      )
    }

    await mkdir(join(cwd, 'tmp'), { recursive: true })
    await writeFile(
      join(cwd, THREADS_FILE),
      JSON.stringify({ threads: earlier.threads }, null, 2) + '\n'
    )
    this.logger.info(
      `Re-reviewing the changes after ${since} with ${earlier.threads.length} earlier comment(s)`
    )
    return { since, threads: earlier.threads }
  }

  /**
   * The token and the repository to post to, from the environment that
   * GitHub Actions sets. Fails before the review starts when one is missing,
   * so a run is not paid for and then lost.
   */
  #postTarget(): { token: string; owner: string; repo: string } | null {
    const token = process.env.GITHUB_TOKEN
    const [owner, repo] = (process.env.GITHUB_REPOSITORY ?? '').split('/')
    const missing = [
      !token && 'GITHUB_TOKEN',
      !(owner && repo) && 'GITHUB_REPOSITORY',
      !this.pr && '--pr',
    ].filter(Boolean)

    if (missing.length) {
      this.logger.error(`--post needs ${missing.join(', ')}`)
      this.exitCode = 1
      return null
    }
    return { token: token!, owner, repo }
  }

  #printCost(cost: ReviewCost) {
    const table = this.ui
      .table()
      .head(['Model', 'Cost', 'Input', 'Output', 'Cache read', 'Cache write'])
    for (const model of cost.models) {
      table.row([
        model.model,
        `$${model.costUsd.toFixed(2)}`,
        String(model.inputTokens),
        String(model.outputTokens),
        String(model.cacheReadInputTokens),
        String(model.cacheCreationInputTokens),
      ])
    }
    table.row(['Total', `$${cost.totalCostUsd.toFixed(2)}`, '', '', '', ''])
    table.render()
    this.logger.info(`${cost.numTurns} turns in ${(cost.durationMs / 1000).toFixed(0)}s`)
  }
}
